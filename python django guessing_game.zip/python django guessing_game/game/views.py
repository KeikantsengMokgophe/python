from django.shortcuts import render
import random

def home(request):
    message = ""
    colour = ""
    game_over = False

    if "secret_number" not in request.session:
        request.session["secret_number"] = random.randint(1, 10)

    secret_number = request.session["secret_number"]   

    if request.method == "POST":
        guess = int(request.POST.get("guess"))

        if guess == secret_number:
            message = f"Correct! The number was {secret_number}."
            colour = "green"
            game_over = True

            request.session["secret_number"] = random.randint(1, 10)

        elif guess < secret_number:
            message = "Too low! Try again."
            colour = "orange"

        else:
            message = "Too high! Try again."
            colour = "red"

    return render(request, "game/home.html", {
        "message": message, 
        "colour": colour,
        "game_over": game_over,

})
